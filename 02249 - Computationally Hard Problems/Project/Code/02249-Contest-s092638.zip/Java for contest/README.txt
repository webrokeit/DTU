compile:
javac MFMST.java

run:
java MFMST filename milliseconds_to_run

example:
java MFMST input.uwg 20000